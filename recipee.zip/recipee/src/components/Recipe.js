import React from 'react';

export default function Recipe(props){
	const recipe = [
		{ 
			id:1,
		  name: 'Tomato Soup',
		  desription: '1 Build a base. Aromatics are the start to any successful soup. ... 2 Spice it up. Herbs and spices add another layer of complexity to even the simplest soup. ...3 Use in season produce. ...4 To puree or not to puree? ...5 Pick your protein. ...6 Make it healthier with grains. ...7 Take it over the top',
		   image:'https://www.vegrecipesofindia.com/wp-content/uploads/2020/11/tomato-soup-recipe-2.jpg',
		},
		{ 
			id:2,
		  name: 'Sandwhich',
		  description: 'Trim the edges of the bread slices,Spread a generous amount of butter on each bread slice,Now spread the green chutney evenly on each slice as well. Use as much or as little as you need,Now place the boiled potatoes on 3 slices in one even layer,Sprinkle some cumin powder and black salt over this,Next, layer cucumber, onions, and tomato slices,Sprinkle more cumin powder and black salt,Place another slice of bread over this that has been buttered and spread with chutney as well,Press down gently so that the ingredients stick together and don’t fall out easily,Repeat until you have 3 large sandwiches,Use a sharp knife to further quarter each into 4 smaller pieces,Plate them and serve immediately with more green chutney, if needed',
		 image:"https://images.unsplash.com/photo-1619096534329-564c333a95b3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c2FuZHdoaWNofGVufDB8fDB8fA%3D%3D&w=1000&q=80",
		},
		{ 
			id:3,
		  name: 'white sauce pasta',
		  description: 'White Pasta Sauce will continue to thicken as it cools down. So serve and enjoy pasta while they are still hot.For cheesy flavor add 2 tablespoons grated cedar cheese or mozzarella cheese in step-10.Use veggies of your choice. Sweet corn, button mushrooms, french beans, onion etc. (total 1 cup chopped veggies) are excellent for creamy white pasta.Before using left over pasta, re-heat them with 1/4 cup milk or water to make sauce thinner.For preparing white pasta in large quantity for party, follow the given steps. Make sauce, boiled pasta, and stir-fried veggies in advance. Then at the time of serving, re-heat the sauce (if sauce is too thick, add little water or milk in it), add boiled pasta and cooked veggies, mix and cook for 1-2 minutes.',
		 image:"https://cdn3.foodviva.com/static-content/food-images/snacks-recipes/white-sauce-pasta/white-sauce-pasta.jpg",
		}
	  ];
function getDetails(){
	
	recipe.map((recipe, id) => {
		
		<div key={id}>
		  <h2>{recipe.name}</h2>
		  <img width='150px'src={recipe.image}/>

		  
		  </div>
		
	  })
	


}

	  return (

		  
		<div>
			<h1>Recipee Book</h1>
         <h2>Tomato Soup</h2>
		 <button  onClick={getDetails(1)}>
		 <img width='150px' src='https://www.vegrecipesofindia.com/wp-content/uploads/2020/11/tomato-soup-recipe-2.jpg'/>
</button>
		 <h2>Sandwhich</h2>
		 <button  onClick={getDetails(2)}>
		 <img width='150px' src='https://images.unsplash.com/photo-1619096534329-564c333a95b3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c2FuZHdoaWNofGVufDB8fDB8fA%3D%3D&w=1000&q=80'/>
         </button>
		 <h2>White sauce pasta</h2>
		 <button  onClick={getDetails(3)}>
		 <img width='150px' src='https://cdn3.foodviva.com/static-content/food-images/snacks-recipes/white-sauce-pasta/white-sauce-pasta.jpg'/>
         </button>
		  
          
		</div>
		
	  );
	
}

