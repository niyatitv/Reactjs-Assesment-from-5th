
import './App.css';
import{useState} from'react';
import Recipe from './components/Recipe.js';


function App() {
  // const[userFormData,setuserFormData]=useState([])
  // let getUserData=(userData)=>{
  //   const userFormDataCopy=[...userFormData]
  //   userFormDataCopy.push(userData)
  //   setuserFormData(userFormDataCopy)
  // }
  return (
    <div className="App">
     
      <Recipe/>
    </div>
  );
}

export default App;
